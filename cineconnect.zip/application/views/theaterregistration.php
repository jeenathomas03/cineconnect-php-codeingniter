
	<body bgcolor='lavender'>
		<center><h1></h1></center>
		<table align="center">
			<form method="post" action="<?php echo base_url();?>Major/tregister">
				<tr><th>Theater Name  </th><td><input type="text" name="theatername" required class="form-control border-primary w-99 py-2 ps-3 pe-4"></td></tr>
				<tr><th>Category  </th><td><input type="text" name="category" required class="form-control border-primary w-99 py-2 ps-3 pe-4"></td></tr>
				<tr><th>City</th><td><input type="text" name="city" required class="form-control border-primary w-99 py-2 ps-3 pe-4"></td></tr>
				<tr><th>Seats</th><td><input type="text" name="seats" required class="form-control border-primary w-99 py-2 ps-3 pe-4"></td></tr>
				<tr><th>Contact </th><td><input type="text" name="contact" required class="form-control border-primary w-99 py-2 ps-3 pe-4"></td></tr>
				<tr><th>Email  </th><td><input type="email" name="email" required class="form-control border-primary w-99 py-2 ps-3 pe-4"></td></tr>
				<tr><th>Password  </th><td><input type="password" name="password" required class="form-control border-primary w-99 py-2 ps-3 pe-4"></td></tr>
				<tr><td></td><td><input type="submit" value="Register" required class="btn btn-success"></td></tr>
			</form>
			</table>
	</body>
