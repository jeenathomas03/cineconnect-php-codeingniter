
	<body bgcolor='lavender'>
		<center><h1></h1></center>
		<table align="center">
			<form method="post" action="<?php echo base_url();?>Major/register">
				<tr><th>Name  </th><td><input type="text" name="name" required class="form-control"></td></tr>
				<tr><th>Contact </th><td><input type="text" name="contact" required class="form-control"></td></tr>
				<tr><th>Email  </th><td><input type="email" name="email" required class="form-control"></td></tr>
				<tr><th>Password  </th><td><input type="password" name="password" required class="form-control"></td></tr>
				<tr><td></td><td><input type="submit" value="Register" required class="btn btn-success"></td></tr>
			</form>
			</table>
	</body>